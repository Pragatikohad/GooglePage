let micIcon = document.querySelector(".mic_icon");

micIcon.addEventListener("click", function () {
    alert("Google Voice Recognition is disabled.");
});
